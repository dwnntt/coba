<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="kamar.php">VIEW</a> | <a href="kamar_add.php">ADD</a>
</body>
</html>
