<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="kota.php">VIEW</a> | <a href="kota_add.php">ADD</a>
</body>
</html>
