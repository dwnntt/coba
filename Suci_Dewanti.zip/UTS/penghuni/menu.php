<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="penghuni.php">VIEW</a> | <a href="penghuni_add.php">ADD</a>
</body>
</html>
